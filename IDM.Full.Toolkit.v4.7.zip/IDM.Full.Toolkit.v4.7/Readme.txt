﻿
####################
# Install notes:
####################

1. Run the executable file;
2. Enjoy in automatically updating and activating of the Internet Download Manager!


NOTE: The toolkit will be recognised as a variant of Win32/Adware.HiRu.L.gen potentially unsafe application,

so you will probably need to add the application in to exclusion list inside your AV!

It will not harm your computer or anything.

It is tested and 100% safe.

For those who are not sure in cleanness of the provided patch, please have VM, Sandboxie or Shadow Defender to install and test the functionalities before they run the application!
